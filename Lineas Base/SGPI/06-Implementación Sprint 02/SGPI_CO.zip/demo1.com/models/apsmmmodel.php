<?php

	class ApsmmModel extends Model{
	
		public function __construct(){
			parent:: __construct();
		}
		
		public funcion consultaSocio(){
		
		}
		
		public funcion consultaSocios(){
			echo "consultar socios";
		}
	
	}
	
?>