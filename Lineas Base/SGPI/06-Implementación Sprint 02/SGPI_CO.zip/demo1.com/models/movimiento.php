<?php

class Movimiento{
  public $cargoabono;
  public $codigoagua;
  public $fechamov;
  public $fecven;
  public $glosa;
  public $mora;
  public $periodo;
  public $saldo;

}




?>