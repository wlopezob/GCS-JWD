<?php

define('URL', 'http://localhost/curso/43.%20MVC/');

define('HOST', 'localhost');
define('DB', 'mvc');
define('USER', 'root');
define('PASSWORD', "123!\"·QWE");
define('CHARSET', 'utf8mb4');

?>