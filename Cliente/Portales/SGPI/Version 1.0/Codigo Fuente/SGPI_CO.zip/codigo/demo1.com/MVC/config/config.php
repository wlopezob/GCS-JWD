<?php

define('URL', 'http://demo1.com/MVC/');

define('HOST', 'sql10.main-hosting.eu');
define('DB', 'u548715087_apsmm');
define('USER', 'u548715087_admi');
define('PASSWORD', "danieleo");
define('CHARSET', 'utf8mb4');

?>