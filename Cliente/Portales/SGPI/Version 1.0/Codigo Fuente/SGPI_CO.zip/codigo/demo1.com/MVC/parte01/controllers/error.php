<?

class Error{

    function __construct(){
        echo "<p>Error al cargar recurso</p>";
    }
}

?>