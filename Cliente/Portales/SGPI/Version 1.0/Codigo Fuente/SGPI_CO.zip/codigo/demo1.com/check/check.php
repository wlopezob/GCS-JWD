<html>
<body>
<form action="procesa.php" method="post">
<input type="checkbox" name="genero[]" value="Hombre"><label>Hombre</label><br/>
<input type="checkbox" name="genero[]" value="Mujer"><label>Mujer</label><br/>
<input type="submit" name="submit" value="Enviar"/>
</form>
<body>
</html>