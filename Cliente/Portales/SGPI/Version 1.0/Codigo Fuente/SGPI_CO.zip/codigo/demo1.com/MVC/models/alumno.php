<?php

class Alumno{

    public $matricula;
    public $nombre;
    public $apellido;
}

?>