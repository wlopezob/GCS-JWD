<?php

$usuario=$_GET["username"];
$clave=$_GET["password"];


if ($usuario=='DANIEL'){

	if ($clave=='admin'){
	     echo "BIENVENIDO AL SISTEMA - USUARIO y CONTRASEÑA CORRECTA";
		 
	}else{
		echo "PASSWORD INCORRECTO";
	}


}else{

echo "USUARIO INCORRECTO";
}


?>