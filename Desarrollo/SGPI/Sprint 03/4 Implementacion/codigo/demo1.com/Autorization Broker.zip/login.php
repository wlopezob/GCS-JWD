<!DOCTYPE html>

<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
	
</head>

<body>
		<div class="box">
		  <h2>Login</h2>
		  <form action="validaingreso.php" method="GET">
  			<b class="msg">

			</b>
		     <div class="inputBox">
			       <input type="text" id="username" name="username" required="">
				   <label>Usuario</label>
			 </div>
			 <div class="inputBox">
				<input type="password" id="password" name="password" required="">
				<label>password</label>
			</div>
			<input type="submit" name="" value="Ingresar">
		  </form>
		  <br>
		<div>
         
		</div>
		</div>

</body>

</html>